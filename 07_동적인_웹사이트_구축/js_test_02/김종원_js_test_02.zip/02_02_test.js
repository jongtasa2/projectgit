function newsync(x){
	for (i=0;i<x ;i++ )
	{
		cc="we're champion";
		document.write(cc + " " + (i+1)+"회 <br>");
	}
	
};

newsync(50);