//jq1.js

$(document).ready(function(){
	$("*").css({"margin":"0px","padding":"0px"})
	$("ul, ol , li").css("list-style","none")
	$("a").css("text-decoration","none")
	$("img").css("border","none")
	$("html, body").css("height","100%")
	$(".tit").css({"position":"relative","left":"50%","top":"50%","margin-left":"-200px","margin-top":"-30px"})
});